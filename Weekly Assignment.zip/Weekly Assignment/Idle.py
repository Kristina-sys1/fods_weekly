Python 3.13.1 (tags/v3.13.1:0671451, Dec  3 2024, 19:06:28) [MSC v.1942 64 bit (AMD64)] on win32
Type "help", "copyright", "credits" or "license()" for more information.
length = 7
width = 6
perimeter = 2* (length + width)
print("perimeter of a rectangle is ",perimeter)
