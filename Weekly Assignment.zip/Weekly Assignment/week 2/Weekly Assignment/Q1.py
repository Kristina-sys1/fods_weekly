l=9
b=6
perimeter=2*l+2*b
print("The Perimeter is ",perimeter)