import math
x=pow(2,10)
print(x)