x = 22/7
txt = f"The 5th decimal is {x:.5f} "
print(txt)