 #This program tries to find the element in the given list
list1=["Kathmandu","Pokhara","Syanja","Nepalgunj","Biratnagar"]

x=input("Enter the name of the city you are looking for")
y=len(list1)

for i in range(y):
    if list1[i]==x:
        print("Congraturlations!, The city you're looking for is found in the index",i)
        break;
else:
    print("City not found in  the loop")

