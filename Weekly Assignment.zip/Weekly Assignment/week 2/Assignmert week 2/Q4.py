# Write a function to accept a list of numbers and print the occurrence of each number. 
# The function should be tested well in the program by calling and sending various list of numbers.

def fun(number):
    occurrence = {} #Empty dictionary to store num
    for i in number:
        if i in occurrence:
          
            occurrence[i]= occurrence[i]+1 
        else:
            occurrence[i]= 1
    for key, value in occurrence.items():
        print(f'{key}: {value}')

num = [1, 2, 3, 2, 3, 2, 2, 1, 1, 3]

print("Occurrences of the number in the list :")
fun(num)
