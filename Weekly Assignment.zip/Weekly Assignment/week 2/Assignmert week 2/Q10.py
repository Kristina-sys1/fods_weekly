#10.  Create a program to ask a user to give continuous input of numbers until they like.
# The program should keep on segregating the user input numbers into even and odd lists separately. 
# Once the user completes the input and opts for exiting the program,
#  the program should display the separate list of even and odd lists in a proper format.

even_num = []#empty list
odd_num = []
print ("To stop the iteration type exit")
while True:
    num = input("Enter a number : ")
    if num.lower()== 'exit':
        break
    try:
        number = int(num)
        if number %2==0:
            even_num.append(number)
        else:
            odd_num.append(number)
    except ValueError: 
        print ("Please enter a valid number")

print ("Even numbers : ", even_num)
print ("Odd numbers : ", odd_num)