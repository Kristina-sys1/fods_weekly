#A program to find the factorial of the users input

x=input("Enter any number")
try:
    x=int(x)
    factorial=1
    for i in range(1,x+1):
        factorial=factorial*i
    print(factorial)
except:
    print("Invalid input")
