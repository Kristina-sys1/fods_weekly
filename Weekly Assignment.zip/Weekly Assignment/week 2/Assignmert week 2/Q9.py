#9. Write a program to ask the details of 5 books (title, author, ISBN, cost), add them in the dictionary and print them. 

book={} #empty dictionary to store details
for i in range (5): #iterate 5 times
    title = input (f"Enter the title of the book {i+1}: ")
    author = input (f"Enter the name of the author of the book {i+1}: ")
    isbn = input (f"Enter the ISBN number of the book {i+1}: ")
    cost = input (f"Enter the cost of the book {i+1}: ")

    book [title]= { 
        "author":author,
        "ISBN" :isbn,
        "Cost": cost
    }
   
    print ("The book details are: ")
    for title, details in book.items():
        print (f"Title: {title}, Author: {details['author']}, ISBN: {details['ISBN']}, Cost: {details['Cost']}")