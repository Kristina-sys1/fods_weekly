#This program shows how to sort the elements in list
list1=["sky","rylee","lily","rose","jonas"]
list1.sort()
print(list1)