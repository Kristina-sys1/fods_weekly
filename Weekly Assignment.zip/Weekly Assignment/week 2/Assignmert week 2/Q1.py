#This program will do some mathematical calculations
x=input("Enter any number")
y=input("Enter any number")
x=int(x)
y=int(y)
def arithmetic_operations():
    sum=x+y
    print(sum)

    diff=x-y
    print(diff)
    


    product=x*y
    print(product)

    remainder=x%y
    print(remainder)
    return arithmetic_operations

arithmetic_operations()


    

    