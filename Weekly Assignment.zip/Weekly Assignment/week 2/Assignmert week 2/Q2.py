#This program will show the working process of arithmetic operations 
x=input("Enter any value:")#Taking user input
y=input("Enter another value:")
#Calculation part

def addition(x,y):#A function to do the addition operation
    sum=int(x)+int(y)
    print(sum)
    return sum
# addition(x,y)

def subtraction(x,y):
    subs=int(x)-int(y)
    print(subs)
    return subs
# subtraction(x,y)

def multiplication(x,y):
    product=int(x)*int(y)
    print(product)
    return product
# multiplication(x,y)

def division(x,y):
    quotient=int(x)/int(y)
    print(quotient)
    return quotient
# division(x,y)

def modulus(x,y):
    md=int(x)%int(y)
    print(md)
    return md
# modulus(x,y)

def floor(x,y):
    f=int(x)//int(y)
    print(f)
    return f
# floor(x,y)

addition(x,y)
multiplication(x,y)
subtraction(x,y)
division(x,y)
modulus(x,y)
floor(x,y)