#8. Write a program to accept a list of numbers from the user and should return a list by removing the duplicate values, if any.

lst = input("Enter the numbers : ")
numbers = lst.split()
numbers = [int(num)for num in numbers]
unique_lst = list(set(numbers))
print (unique_lst)
