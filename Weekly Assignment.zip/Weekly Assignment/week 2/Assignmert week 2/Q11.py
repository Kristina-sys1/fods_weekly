 #11. Write a program to generate a card guessing game for the users in an interesting way. 
#The card should have property such as name and value (e.g. ace 10). Specifications are as mentioned below.
    #I.	The program should have a list of card values like 2, 3, 4,…., Jack, Queen, King, Ace
    #II.	The program should have a list of card suits like heart, diamond, club, spades.
    #III.	The program should randomly pick up a number and a suit and keep as an answer in a separate list.
    #IV.	The program should ask the player to guess the card value and the suit.
    #V.	The program should check the player guessed value with the computer answer value. 
        #If both the parts don’t match, the program should show a broken heart and game over to the player. 
        #If any one of the part of answer matches, the program should show a smily face to the player. 
        #If both the guesses of the player matches with the program answer, the program should show a heart and a smily face to the user.

import random

print ("Write the first letter in Capital letter")
print( "Cards Values: 2, 3, 4, 5, 6, 7, 8, 9, 10, Jack, Queen, King, Ace ")
print ("Cards Suits: Heart, Diamond, Club, Spades")
cards_values = ["2","3","4","5","6","7","8","9","10","Jack","Queen","King","Ace"]
card_suits = ["Heart", "Diamond", "Club", "Spades"]
#Picking random card value and suit
random_card = random.choice(cards_values)
random_suit = random.choice(card_suits)
#Guessing the card value and suit
guess_value = input("Guess the card value : ")
guess_suit = input("Guess the card suit : ")


if guess_value == random_card and guess_suit == random_suit:

    print (" ❤️ 😄 You guessed both Value and Suit correctly!!!")
elif guess_value == random_card or guess_suit == random_suit:
    print (" 😄 You guessed one of it correctly!!!")
else:
    print(" 💔 Game over! Better Luck next time")

