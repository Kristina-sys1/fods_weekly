#7. Write a function word_frequency(sentence) that takes a sentence as input and 
# returns a dictionary containing the frequency of each word in the sentence. 
# [Hint: split the sentence into words and iterate to check the word frequency.]

def word_frequency (sentence):
    sentence = str.split() 
    words= set(sentence)
    for word in words:
        print ("Frequency of", word , "is : ", sentence.count(word))
#Driver code
if __name__ == "__main__":# this condition checks if script is being run directly
    str = "fruits apple mango vggies mushroom potato potato tomato tomato"
    word_frequency(str)