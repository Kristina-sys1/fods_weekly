#This program displays prime numbers 
print("Give the range of numbers to print prime numbers in between them")
x=input("Enter the starting number")
y=input("Enter the ending number")

try:
    x=int(x)
    y=int(y)
    for a in range(x, y + 1):
   # all prime numbers are greater than 1
       if a > 1:
           for i in range(2, a):
               if (a % i) == 0:
                   break
           else:
               print(a)
           
except:
    print("Invalid Input")