import random


print("Welcome to the Number Guessing Game!")
    
    # Set the range for the number to guess
lower_num = 1
upper_num= 100
    
    # Generate a random number between the lower and upper bounds
guess = random.randint(lower_num, upper_num)
    
    # Initialize the number of attempts
trials = 0
    
    # Start the game loop
while True:
        # Ask the user for their guess
        try:
            user= int(input(f"Guess the number between {lower_num} and {upper_num}: "))
        except:
            print("Invalid")
            continue
        
        trials += 1
        
        # Check if the guess is too low, too high, or correct
        if user < guess:
            print(" lower than the original! Try again.")
        elif user > guess:
            print("higher than the original! Try again.")
        else:
            print(f"Congratulations! You guessed the number {guess} in {trials} attempts.")
            break

