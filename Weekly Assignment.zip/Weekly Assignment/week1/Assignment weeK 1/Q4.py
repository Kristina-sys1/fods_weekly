#Program calculated the mathematical expressions 
x=input("Enter any number")
y=input("Enter another number")
z=input("Enter another number again")
try:
    x=int(x)
    y=int(y)
    z=int(z)

    import math#Math is imported so to use the function pow
    result1=math.pow(x,2)+2*x*y+math.pow(y,2)
    result2=math.pow(x,5)+2*x*y*z+math.pow(y,3)+math.pow(z,4)
    result3=math.pow(x,7)+5*math.pow(x,3)*math.pow(y,2)*math.pow(z,6)+math.pow(y,7)
    print(result1)
    print(result2)
    print(result3)



except:
    print("Invalid Input")