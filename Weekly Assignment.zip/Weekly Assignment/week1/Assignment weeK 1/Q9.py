#A program to find the sum of all the user input values

def sum():
    sum_even = 0
    sum_odd = 0

    while True:
        try:
            x = int(input("Enter a number or type 0 to stop entering numbers: "))
            if x == 0:
                break  # StopS taking numbers

            if x % 2 == 0:
                sum_even += x
            else:
                sum_odd += x
        except:
            print("Invalid input")

    print("Sum of Even Numbers: ",+sum_even)
    print("Sum of Odd Numbers: ",+sum_odd)

while True:
    print("MENU:")
    print("Choice 1: Enter numbers and calculate sum of odd/even numbers")
    print("Choice 2: Exit")

    choice = input("Enter your choice (1/Q): ")
    if choice == "1":
        sum()
    elif choice == "Q":
        print("Exit")
        break
    else:
        print("Invalid choice! Please enter 1 or Q.")
