#This program shows the spreadsheet of a students result
math=input("Enter your marks in Maths")
physics=input("Enter your marks in Physics")
chemistry=input("Enter your marks in Chemistry")
biology=input("Enter your marks in Biology")
english=input("Enter your marks in English")

try:
    math=int(math)
    physics=int(physics)
    chemistry=int(chemistry)
    biology=int(biology)
    english=int(english)

    total=math+physics+chemistry+biology+english
    print("The tolal marks you obtained is",+total)

    average=total/5
    print("The average marks you obtained is",+average)

    percentage=total*100/500
    print("You obtained percentage=",+percentage)

    if percentage>80:
        print("You've scored distinction. Congratulations")

    elif percentage>60 or percentage<50:
        print("You've scored first division.Conggratulations")

    elif percentage>50 or percentage<45:
        print("You've scored Second division.You can do much Better")

    else:
        print("Try again next time, You've Failed")

except:
    print("Invalid Input, Keep your Marks in a Right Way")


