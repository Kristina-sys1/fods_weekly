#This program will show the working process of arithmetic operations 
x=input("Enter any value:")#Taking user input
y=input("Enter another value:")
#Calculation part

def addition(x,y):#A function to do the addition operation
    sum=int(x)+int(y)
    print(sum)
    return sum
# addition(x,y)

def subtraction(x,y):
    subs=int(x)-int(y)
    print(subs)
    return subs
# subtraction(x,y)

def multiplication(x,y):
    product=int(x)*int(y)
    print(product)
    return product
# multiplication(x,y)

def division(x,y):
    quotient=int(x)/int(y)
    print(quotient)
    return quotient
# division(x,y)

def modulus(x,y):
    md=int(x)%int(y)
    print(md)
    return md
# modulus(x,y)

def floor(x,y):
    f=int(x)//int(y)
    print(f)
    return f
# floor(x,y)

user=input("What arithmetic operation do you want to do? A=Addition, S=substraction, M=Multiplication, D=Division, M_d=Modulous division, F=Floor Division: ")

if user=="a" or user=="A":
    addition(x,y)
elif user=="s" or user=="S":
    subtraction(x,y)
elif user=="m" or user=="M":
    multiplication(x,y)
elif user=="d" or user=="D":
    division(x,y)
elif user=="M_d":
    modulus(x,y)
elif user=="f" or user=="F":
    floor(x,y)
else:
    print("INVALID INPUT")



