#This program shows how to differentiate between even and odd
x=input("Enter any number:")#Taking user input

#If condition to check the value
try:
    x=int(x)
    if x%2==0:
        print("even")
    elif x%2!=0:
        print("odd")
except:
    print("Invalid Input")
    