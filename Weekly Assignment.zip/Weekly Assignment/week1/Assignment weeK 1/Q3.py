#This program shows some mathematical calculations.
x=input("Enter any number:")
y=input("Enter the exponent value")
#Calculation 
try:
    x=int(x)
    y=int(y)
    square=x*x
    print(square)

    square_root=x**0.5
    print(square_root)

    result=x**y#Calculation of exponintial value
    print(result)

    a=x*x*x
    b=x*x*x*x
    c=x*x*x*x*x
    print("The 3rd power is",+a)
    print("The 4th power is",+b)
    print("The 5th power is",+c)

    import math#The math function is imported to perform the log calculation
    log_value=math.log10(x)
    print("The log value is ",+log_value)


except:
    print("Invalid Input")