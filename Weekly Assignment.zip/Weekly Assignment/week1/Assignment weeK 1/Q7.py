#A program to find all the numbers divisible by 7 and not a multiple of 5


for i in range(2000,3200+1):
    if i%7==0 and i%5!=0:#Condition to find the appropriate numbers
        print(i)
    else:
        print()

x=input("Enter the starting number of thne range")
y=input("Enter the ending number of the range")

try:
    x=int(x)
    y=int(y)
    for j in range(x,y+1):
        if j%7==0 and j%5!=0:#Condition to find the appropriate numbers
            print(j)
        else:
            print()
except:
    print("Invalid Input")


